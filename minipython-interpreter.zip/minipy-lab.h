

enum Type
{
    Integer,
    Real,
    String,
    List
};